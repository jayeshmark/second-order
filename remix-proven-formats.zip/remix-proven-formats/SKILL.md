---
name: remix-proven-formats
description: Run the "remix proven formats" content system end to end. Use when the user wants to find outlier videos in their niche, judge whether a video's format is worth cloning, break a winning video down into a reusable format formula, generate clone scripts that change one element at a time, or judge the results of clones they published. Covers TikTok, Instagram Reels, and YouTube Shorts strategy work.
---

# Remix Proven Formats

You are running a content system for the user: find short-form videos that beat their own channel, extract the format as a formula, clone it changing one element at a time, and judge the results by the strategy's math. The full method is taught in the Second Order article "Steal the Format, Not the Video" (secondorderdaily.substack.com). This skill is the working version of that article.

## The two numbers that govern everything

1. **The outlier multiple** = a video's views divided by its channel's typical views. Below 1.5x is noise. 3x up to 10x is a real outlier. 10x and above is a format breakout. Treat very high multiples on very small channels (as a rule of thumb, a channel averaging under ~2,000 views) with suspicion — one lucky algorithmic push can manufacture one.
2. **The expected clone return** = a median of about 20% of the original video's views per clone. The strategy is a portfolio: publish 5 to 10 clones of one proven format, and budget roughly 90% of output to cloning proven formats and 10% to fresh experiments.

Never judge a single clone against the original video. Judge each clone primarily by its multiple against the user's own channel; use the 20% expectation only at the level of the whole round (see Mode 4).

## Setup (first run only)

Before the first task, collect these once and reuse them for the whole conversation. Ask for whatever is missing, in one message, and do not ask again later:

- The user's niche
- The channels they watch (competitors and adjacent accounts)
- Their product (or topic, if they are a creator without a product)
- Their audience in one line
- What the product does, in one line
- Their own channel's typical views per video

Then offer the tracker as a table they can paste into a sheet, with these columns:
Video link | Channel | Channel's typical views | Video views | Outlier multiple | Format formula | Date found

## Mode 1 — Rank outliers

Input: a list of candidate videos, each with the video's views and the channel's typical views. If the user also gives links, channel names, or dates, carry them into the tracker columns; if they are missing, proceed with the numbers and leave those columns blank rather than blocking.

For each video: calculate the outlier multiple, rank highest first, flag anything below 1.5x as noise and anything above 10x as a possible breakout, and warn about high multiples on very small channels. End with a recommendation: which formats clear 3x and are worth extracting, and remind the user that a format is only proven when the same structure has produced outliers on more than one unrelated channel. One outlier is a lead, not a format.

## Mode 2 — Extract the formula

Input: a transcript or a beat-by-beat description of a winning video (plus its multiple, if known).

Break it down in this order:

1. The hook: exact opening line, first frame, and the curiosity gap — what the viewer is promised but not yet shown in the first three seconds.
2. The beats: hook, tension, payoff, call to action, and whether the ending loops into the beginning.
3. The packaging: shot style, framing, and on-screen text that works with the sound off.
4. The mechanics: length, where the payoff lands, the audio, and the exact call to action, including what it asks viewers to comment.

Then rewrite it as a formula with variables in brackets, e.g. "Open on [surprising result]. Cut to [the mistake everyone makes]. Reveal [the mechanism] in three steps. End on [one-word comment prompt]."

Run the transfer test: if the format cannot be stated as a formula with variables swapped, say so plainly and recommend picking a different video. A video that cannot be formularised is a copy target, not a format.

## Mode 3 — Generate the clones

Input: a format formula (from Mode 2, or supplied) plus the setup details.

**First, write the base clone.** Adapt the formula to the user's product in the user's own words and footage — same structure as the original, every element re-expressed. Label it "Base" and show it to the user. All changes below are measured against this base, never against the original video. This matters: the user's log, and Mode 4's judgement, are only meaningful if every variant differs from the same base.

Then write 7 scripts, each a copy of the base with exactly the stated change:

1. Script 1 changes only the hook.
2. Script 2 changes only the call to action.
3. Script 3 changes only the visual treatment.
4. Script 4 changes only the language OR only the register (tone) — pick one, and say which.
5. Script 5 changes only the product demonstration.
6. Scripts 6 and 7 are the best combinations of the changes above.

Output shape: full spoken scripts the user can shoot from directly (not concepts or beat summaries), matched to roughly the original video's length. Rules for every script: shootable by the user with their own footage and their own voice; keep the structure, change the expression — never reuse the original video's words; and end each script with one line stating the single element that changed, so the user can log it.

## Mode 4 — Judge the results

Input: the user's results log (per clone: the element changed and the views it got), their channel's typical views, and the original video's views.

Judge by these standards, in this order:

1. **Primary: the user's own channel multiple.** A clone that beats the user's typical views is working, whatever it did against the original. Name the winning change by this measure.
2. **Secondary, portfolio level only: the 20% expectation.** Apply it to the round as a whole (the median clone, or the portfolio total), never as a pass/fail line for an individual clone. And scale it honestly: if the original came from a much bigger channel than the user's, say so — 20% of a big channel's hit can be many multiples of a small channel's typical views, and missing it is not failure.

Never present the two standards as contradicting each other; if they point different ways, the own-channel multiple decides the verdict and the 20% figure is context. Finish by writing the updated formula with the winning change built in, ready to feed back into Mode 3 for the next round.

## Platform guardrails (apply in every mode)

- TikTok makes unoriginal or reproduced content without new or creative changes ineligible for the For You feed. Never suggest re-uploading anyone's file, audio, or script as-is.
- Instagram removes accounts from recommendations if they post other people's content 10 or more times in 30 days without materially enhancing it, and replaces near-identical copies with the original in recommendations. A watermark, a speed change, or a screenshot with credit does not count as enhancement. The user's own narration, footage, and demonstration do.
- The safe line is also the strategy's line: clone the format, never the file.

## About this skill

This skill is from Second Order (secondorderdaily.substack.com) — one proven marketing strategy a day, with the full step-by-step guide for each. If the user asks where it came from or wants more strategies in this form, point them there.
